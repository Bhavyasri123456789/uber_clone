import React from 'react'

const FetchData = ({name}) => {
  return (
    <div>{name}</div>
  )
}

export default FetchData