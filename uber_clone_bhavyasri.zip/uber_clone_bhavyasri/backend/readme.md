

### today
  1. create db file name db.js and connect with database
  2. create model for user 
      name:String
      email:String
      password :String
 3. create login functionality and implement and connect this in frontend as well
 