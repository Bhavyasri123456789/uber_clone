// import logo from './logo.svg';
import './App.css';
import Notification from "./components/Notifications";

function App() {
  return (
    <div className="App">
      <Notification/>
    </div>
  );
}

export default App;
